package com.example.SpringCRUD.entity;

import jakarta.persistence.Entity;
