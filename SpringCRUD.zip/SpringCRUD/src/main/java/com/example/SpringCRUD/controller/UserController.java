package com.example.SpringCRUD.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringCRUD.entity.User;
import com.example.SpringCRUD.service.UserService;

@RestController
public class UserController {
@Autowired	
public UserService service;
	
	@PostMapping("/adduser")
	//post mapping -- is to save data
	public User addUser(@RequestBody User usr) {
		return service.addUser(usr);
	}
	
	
	@GetMapping("/getuser")
	public List<User> getUser() {
		return service.getUser();
	}
	
	@DeleteMapping("/deleteuser/{id}")
	public void deleteUser(@PathVariable Long id) {
		service.deleteUser(id);
	}
	
	@PutMapping("/updateuser")
	public User updateuser(@RequestBody User usr) {
		return  service.updateUSer(usr);
	}
}
