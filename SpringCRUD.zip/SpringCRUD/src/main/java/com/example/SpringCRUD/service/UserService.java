package com.example.SpringCRUD.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringCRUD.entity.User;
import com.example.SpringCRUD.repository.UserRepo;
@Service
public class UserService {
@Autowired
	private UserRepo usrpo;
	
	//adding employee details
	public User addUser(User usr) {
		return usrpo.save(usr);
	}
	
	
	//read the employee details
	public List<User> getUser() {
		return usrpo.findAll();
	}
	
	//delete
//	public void deleteUser(Long id) {
//		((UserService) usrpo).deleteUser(id);;
//	}
	public void deleteUser(Long id) {
		usrpo.deleteById(id);;
	}

	//update
		public User updateUSer(User usr) {
			long usrid = usr.getId();
			//User usr1 = usrpo.findById(usrid).get();
			User usr1 = usrpo.findById(usrid).get();
			usr1.setName(usr.getName());
			usr1.setType(usr.getType());
			usr1.setPassword(usr.getPassword());
			return usrpo.save(usr1);
		}


}
