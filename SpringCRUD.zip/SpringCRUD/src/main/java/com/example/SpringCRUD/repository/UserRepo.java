package com.example.SpringCRUD.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SpringCRUD.entity.User;



public interface UserRepo extends JpaRepository<User,Long>{

}
